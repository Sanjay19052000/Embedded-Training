#include <stdio.h>
#include <stdlib.h>
#define pi 3.14

int main()
{
   int radius,area;
   printf("enter the radius\n");
   scanf("%d",&radius);

   area=(pi*radius)/2;
   printf("the area of square is %d\n",area);
}

/*
