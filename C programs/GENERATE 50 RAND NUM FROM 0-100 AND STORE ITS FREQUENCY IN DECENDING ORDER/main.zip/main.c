#include <stdio.h>
#include <stdlib.h>
#include<math.h>

int main()
{
    int i,j,temp,k,nex;
    int arr[60];
    int arr1[50],arr2[50],arr3[50],arr4[50];

    // temp=(rand()%100);
    // printf("%d",temp);

    for(i=0; i<50; i++)
    {
        arr[i]=(rand()%100);
    }

    for (i=0; i<50; i++)
    {
        for (j=0; j<50; j++)
        {

            if (arr[i]==arr[j])
            {
                temp=++temp;

                if (temp==4)
                {
                   nex=arr[i];
                   arr[i]=arr[j];
                   arr[j]=nex;
                   printf("4 times %d\n",arr[i]);
                }
               if (temp==3)
                {
                    nex=arr[i];
                   arr[i]=arr[j];
                   arr[j]=nex;
                   printf("3 times %d\n",arr[i]);
                }
              if (temp==2)
                {
                    nex=arr[i];
                   arr[i]=arr[j];
                   arr[j]=nex;
                   printf(" 2 times %d\n",arr[i]);
                }
                else
                {
                    nex=arr[i];
                   arr[i]=arr[j];
                   arr[j]=nex;
                   printf("one time %d\n",arr[j]);
                }
            }
        }
    }
//
//    for (i=0;i<=50;i++)
//    {
//        printf("4 times repeated %d\n",arr[i]);
//
//    }


}

